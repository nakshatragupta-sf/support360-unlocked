# Support360 — 10 Incremental Upgrades

Each upgrade is a self-contained, deployable change. Work through them in order — each builds on the previous. After each upgrade, create a new package version to simulate a real release cycle.

---

## How to Apply Any Upgrade

```bash
# 1. Make the code/metadata changes described below
# 2. Push to your scratch org
sf project deploy start --target-org Support360Dev

# 3. Run tests to verify
sf apex run test --target-org Support360Dev --result-format human

# 4. Create a new package version
sf package version create \
  --package 'Support360' \
  --installation-key-bypass \
  --code-coverage \
  --wait 20 \
  --target-dev-hub DevHub

# 5. Install new version in a test org and verify
# 6. Promote when ready
```

---

## Upgrade 1 — Add a "Resolution Notes" Text Field to Case

**Why:** Agents need a structured field to log how a case was resolved, separate from the general Description. This is the simplest possible metadata-only change.

**What to add:**

Create file: `force-app/main/default/objects/Case/fields/Resolution_Notes__c.field-meta.xml`

```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>Resolution_Notes__c</fullName>
    <label>Resolution Notes</label>
    <type>LongTextArea</type>
    <length>32768</length>
    <visibleLines>5</visibleLines>
    <description>Agent notes on how the case was resolved. Required on close.</description>
    <required>false</required>
    <trackHistory>false</trackHistory>
</CustomField>
```

**Update Permission Sets** — add to both `Support360_Admin` and `Support360_User`:
```xml
<fieldPermissions>
    <editable>true</editable>
    <readable>true</readable>
    <field>Case.Resolution_Notes__c</field>
</fieldPermissions>
```

**Test:** Create a Case, close it, and verify the field is editable on the record.

**Version bump:** `1.1.0.NEXT`

---

## Upgrade 2 — Add SLA Breach Email Alert via Flow

**Why:** When SLA_Status__c changes to "Breached", the case owner should receive an email. Flows are the recommended declarative automation mechanism.

**What to add:**

Create file: `force-app/main/default/flows/Notify_Owner_On_SLA_Breach.flow-meta.xml`

This is a **Record-Triggered Flow** on Case:
- Trigger: After Update
- Condition: `SLA_Status__c` CHANGED TO `Breached`
- Action: Send Email Alert to `{!$Record.Owner.Email}` with Subject "SLA Breached: {!$Record.CaseNumber}"

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Flow xmlns="http://soap.sforce.com/2006/04/metadata">
    <apiVersion>62.0</apiVersion>
    <label>Notify Owner On SLA Breach</label>
    <processType>AutoLaunchedFlow</processType>
    <status>Active</status>
    <triggerType>RecordAfterSave</triggerType>
    <object>Case</object>
    <triggerOrder>2</triggerOrder>
    <recordTriggerType>Update</recordTriggerType>
    <filterFormula>AND(
        ISPICKVAL({!$Record.SLA_Status__c}, "Breached"),
        ISPICKVAL({!$Record__Prior.SLA_Status__c}, "At Risk")
    )</filterFormula>
    <!-- Add Send Email core action here in Flow Builder -->
    <start>
        <locationX>176</locationX>
        <locationY>48</locationY>
    </start>
</Flow>
```

**Recommended:** Build this visually in Flow Builder and use sf project retrieve start to pull it down.

**Version bump:** `1.2.0.NEXT`

---

## Upgrade 3 — Parameterize SLA Hours via Custom Metadata

**Why:** Hardcoded SLA hours in `SLACalculator.cls` are inflexible. Enterprise customers need to configure their own SLA targets. Custom Metadata Types solve this without changing code.

**Step A — Create the Custom Metadata Type**

Create: `force-app/main/default/objects/SLA_Configuration__mdt/`

`SLA_Configuration__mdt.object-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
    <label>SLA Configuration</label>
    <pluralLabel>SLA Configurations</pluralLabel>
    <visibility>Public</visibility>
</CustomObject>
```

`fields/Resolution_Hours__c.field-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>Resolution_Hours__c</fullName>
    <label>Resolution Hours</label>
    <type>Number</type>
    <precision>6</precision>
    <scale>0</scale>
</CustomField>
```

**Step B — Create Records for Each Priority**

Create `customMetadata/SLA_Configuration.Critical.md-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata">
    <label>Critical</label>
    <protected>false</protected>
    <values>
        <field>Resolution_Hours__c</field>
        <value xsi:type="xsd:double" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">4</value>
    </values>
</CustomMetadata>
```
Repeat for High (8), Medium (24), Low (72).

**Step C — Update SLACalculator.cls**

Replace the hardcoded map with a CMDT query:
```apex
private static Map<String, Integer> loadSLAConfig() {
    Map<String, Integer> config = new Map<String, Integer>();
    for (SLA_Configuration__mdt rec : [
        SELECT MasterLabel, Resolution_Hours__c
        FROM SLA_Configuration__mdt
        WITH USER_MODE
    ]) {
        config.put(rec.MasterLabel, (Integer)rec.Resolution_Hours__c);
    }
    return config;
}
```

**Version bump:** `1.3.0.NEXT`

---

## Upgrade 4 — Add a "Last Escalation Date" Field

**Why:** Audit trail for escalations. Managers need to know when escalation occurred, not just the current level.

**What to add:**

`force-app/main/default/objects/Case/fields/Last_Escalation_Date__c.field-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>Last_Escalation_Date__c</fullName>
    <label>Last Escalation Date</label>
    <type>DateTime</type>
    <description>Timestamp of the most recent escalation event.</description>
    <required>false</required>
    <trackHistory>true</trackHistory>
</CustomField>
```

**Update EscalationService.cls** — in both `escalateCase()` and `autoEscalateOnBreach()`, add:
```apex
c.Last_Escalation_Date__c = DateTime.now();
```

**Add test assertion** in `EscalationServiceTest`:
```apex
Assert.isNotNull(updated.Last_Escalation_Date__c, 'Last escalation date should be set');
```

**Version bump:** `1.4.0.NEXT`

---

## Upgrade 5 — Add a "Time to Resolve" Formula Field

**Why:** Reporting on actual resolution time vs SLA target is a core metric for support ops dashboards.

**What to add:**

`force-app/main/default/objects/Case/fields/Time_To_Resolve_Hours__c.field-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>Time_To_Resolve_Hours__c</fullName>
    <label>Time to Resolve (Hours)</label>
    <type>Number</type>
    <formula>IF(IsClosed,
        (ClosedDate - CreatedDate) * 24,
        NULL
    )</formula>
    <formulaTreatBlanksAs>BlankAsZero</formulaTreatBlanksAs>
    <precision>8</precision>
    <scale>1</scale>
    <description>Actual hours from case creation to closure. NULL for open cases.</description>
</CustomField>
```

No Apex changes required — pure metadata. Add to permission sets as read-only.

**Version bump:** `1.5.0.NEXT`

---

## Upgrade 6 — Add a "CSAT Score" Field and Rating Component

**Why:** Customer Satisfaction (CSAT) is the primary KPI for most support teams. Adding a 1–5 score field closes the loop between SLA performance and customer perception.

**Step A — Add the field:**

`force-app/main/default/objects/Case/fields/CSAT_Score__c.field-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>CSAT_Score__c</fullName>
    <label>CSAT Score (1-5)</label>
    <type>Number</type>
    <precision>1</precision>
    <scale>0</scale>
    <description>Customer satisfaction rating submitted after case closure. 1=Very Dissatisfied, 5=Very Satisfied.</description>
    <required>false</required>
</CustomField>
```

**Step B — Add to LWC summary tiles** in `supportDashboard.js`:
```javascript
get averageCsat() {
    const scored = this.cases.filter(c => c.CSAT_Score__c);
    if (!scored.length) return 'N/A';
    const avg = scored.reduce((sum, c) => sum + c.CSAT_Score__c, 0) / scored.length;
    return avg.toFixed(1);
}
```

**Version bump:** `1.6.0.NEXT`

---

## Upgrade 7 — Add a CaseTriggerHandler class (Trigger Framework Refactor)

**Why:** As the trigger grows, a dedicated handler class makes it testable in isolation and keeps the trigger file itself clean. This is an architectural improvement — no change in behavior.

**What to add:**

`force-app/main/default/classes/CaseTriggerHandler.cls`:
```apex
public with sharing class CaseTriggerHandler {

    public void beforeInsert(List<Case> newCases) {
        SLACalculator.calculateSLAFields(newCases);
    }

    public void beforeUpdate(List<Case> newCases, Map<Id, Case> oldMap) {
        SLACalculator.calculateSLAFields(newCases);
        SLACalculator.refreshSLAStatus(newCases);
    }

    public void afterUpdate(List<Case> newCases, Map<Id, Case> oldMap) {
        EscalationService.autoEscalateOnBreach(newCases, oldMap);
    }
}
```

**Update CaseTrigger.trigger:**
```apex
trigger CaseTrigger on Case (before insert, before update, after update) {
    CaseTriggerHandler handler = new CaseTriggerHandler();
    if (Trigger.isBefore && Trigger.isInsert)  handler.beforeInsert(Trigger.new);
    if (Trigger.isBefore && Trigger.isUpdate)  handler.beforeUpdate(Trigger.new, Trigger.oldMap);
    if (Trigger.isAfter  && Trigger.isUpdate)  handler.afterUpdate(Trigger.new, Trigger.oldMap);
}
```

**Version bump:** `1.7.0.NEXT`

---

## Upgrade 8 — Add a getCasesWithSLA Apex Method for the LWC Wire

**Why:** The `supportDashboard.js` imports `getCasesWithSLA` from Apex but the method doesn't exist in the package yet — this upgrade wires it up properly.

**Add to SLACalculator.cls:**
```apex
@AuraEnabled(cacheable=true)
public static List<Case> getCasesWithSLA() {
    return [
        SELECT Id, CaseNumber, Subject, Priority, Status, IsClosed,
               SLA_Status__c, SLA_Breach_Date__c, SLA_Hours_By_Priority__c,
               Escalation_Level__c, Owner.Name, CreatedDate, ClosedDate
        FROM Case
        WHERE IsClosed = false
        WITH USER_MODE
        ORDER BY SLA_Status__c, Priority, CreatedDate DESC
        LIMIT 200
    ];
}
```

**Add test method** in `SLACalculatorTest.cls`:
```apex
@IsTest
static void testGetCasesWithSLA_returnsOpenCasesOnly() {
    insert new Case(Subject='Open SLA Test', Priority='High', Status='New');
    insert new Case(Subject='Closed SLA Test', Priority='Low', Status='Closed');

    Test.startTest();
    List<Case> result = SLACalculator.getCasesWithSLA();
    Test.stopTest();

    for (Case c : result) {
        Assert.isFalse(c.IsClosed, 'Should only return open cases');
    }
}
```

**Version bump:** `1.8.0.NEXT`

---

## Upgrade 9 — Add a `TriggerControl__c` Custom Setting to Disable Triggers

**Why:** Every production support package needs a kill switch. If a customer's data migration is causing trigger fires they don't want, they need an admin-accessible toggle. This is a standard ISV pattern.

**Step A — Create the Hierarchy Custom Setting:**

`force-app/main/default/objects/TriggerControl__c/TriggerControl__c.object-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
    <customSettingsType>Hierarchy</customSettingsType>
    <description>Org-wide and user-level toggle for Support360 triggers. Disable during data migrations.</description>
    <enableEnhancedLookup>false</enableEnhancedLookup>
    <label>Trigger Control</label>
    <visibility>Public</visibility>
</CustomObject>
```

`fields/Disable_Case_Trigger__c.field-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>Disable_Case_Trigger__c</fullName>
    <label>Disable Case Trigger</label>
    <type>Checkbox</type>
    <defaultValue>false</defaultValue>
</CustomField>
```

**Step B — Guard CaseTrigger:**
```apex
trigger CaseTrigger on Case (before insert, before update, after update) {
    TriggerControl__c settings = TriggerControl__c.getInstance();
    if (settings != null && settings.Disable_Case_Trigger__c) {
        return; // Trigger disabled — exit immediately
    }
    CaseTriggerHandler handler = new CaseTriggerHandler();
    // ... rest of trigger
}
```

**Version bump:** `1.9.0.NEXT`

---

## Upgrade 10 — Add a Support360 App with a Custom Tab

**Why:** Deploy-and-discover. Instead of requiring admins to manually add the dashboard LWC to pages, package a Lightning App with the tab pre-configured so the app appears in the App Launcher on install.

**Step A — Create the App:**

`force-app/main/default/applications/Support360.app-meta.xml`:
```xml
<?xml version="1.0" encoding="UTF-8"?>
<CustomApplication xmlns="http://soap.sforce.com/2006/04/metadata">
    <defaultLandingTab>standard-Case</defaultLandingTab>
    <description>Support360 — SLA Tracking and Case Escalation</description>
    <isNavAutoTempTabsDisabled>false</isNavAutoTempTabsDisabled>
    <isNavPersonalizationDisabled>false</isNavPersonalizationDisabled>
    <label>Support360</label>
    <navType>Standard</navType>
    <tabs>standard-Case</tabs>
    <tabs>Support360Dashboard</tabs>
    <uiType>Lightning</uiType>
    <utilityBar>Support360UtilityBar</utilityBar>
</CustomApplication>
```

**Step B — Create the FlexiPage for the Dashboard tab:**

Use `sf page generate` or build in Experience Builder, then:
```bash
sf project retrieve start \
  --metadata FlexiPage:Support360_Dashboard \
  --target-org Support360Dev
```

**Step C — Bump the version name to reflect this is now a full product release:**

In `sfdx-project.json`:
```json
"versionName": "Support360 v2.0 — Full Product Release",
"versionNumber": "2.0.0.NEXT"
```

**Version bump:** `2.0.0.NEXT` — this is a major version because we've added an installable App

---

## Summary of All 10 Upgrades

| # | Change | Type | Version |
|---|--------|------|---------|
| 1 | Resolution Notes text field | Metadata | 1.1.0 |
| 2 | SLA Breach email alert (Flow) | Automation | 1.2.0 |
| 3 | SLA hours via Custom Metadata | Architecture | 1.3.0 |
| 4 | Last Escalation Date field | Metadata + Apex | 1.4.0 |
| 5 | Time to Resolve formula field | Metadata | 1.5.0 |
| 6 | CSAT Score field + LWC tile | Metadata + LWC | 1.6.0 |
| 7 | Trigger Handler class refactor | Architecture | 1.7.0 |
| 8 | getCasesWithSLA Apex method | Apex | 1.8.0 |
| 9 | TriggerControl kill switch | Architecture | 1.9.0 |
| 10 | Support360 Lightning App + Tab | UX / Product | 2.0.0 |
