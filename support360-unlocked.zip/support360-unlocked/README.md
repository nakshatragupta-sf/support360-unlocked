# Support360 — Unlocked Package

A production-quality Salesforce Unlocked Package for the **Support industry** that adds SLA tracking, escalation management, and a real-time dashboard to your Service Cloud org.

Built to demonstrate the complete Unlocked Package lifecycle: from local development → scratch org → package creation → versioning → upgrade path.

---

## What This App Does

**Support360** extends the standard Salesforce `Case` object with:

| Feature | Description |
|---|---|
| **SLA Tracking** | Auto-calculates SLA breach dates by priority (Critical 4h / High 8h / Medium 24h / Low 72h) |
| **SLA Status** | Real-time picklist: Within SLA / At Risk / Breached / Excluded |
| **Escalation Engine** | Auto-escalates cases on breach; manual escalation via dashboard |
| **Escalation Levels** | L1 Frontline → L2 Senior Agent → L3 Specialist → L4 Manager |
| **Support Dashboard** | LWC component showing all open cases with SLA status tiles and escalate button |
| **Permission Sets** | `Support360_Admin` (full access) and `Support360_User` (read SLA fields) |

---

## Prerequisites

- [ ] **Salesforce CLI** installed — `sf --version` ≥ 2.x  
  Download: https://developer.salesforce.com/tools/salesforcecli
- [ ] **Node.js** 18 LTS or higher — `node --version`
- [ ] **Git** — `git --version`
- [ ] **VS Code** with Salesforce Extension Pack installed
- [ ] A **Developer Edition org** with **Dev Hub enabled** (Setup → Dev Hub → Enable)
- [ ] Free DE org: https://developer.salesforce.com/signup

---

## Quick Start (Clone → Scratch Org → Deploy in ~5 minutes)

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_ORG/support360-unlocked.git
cd support360-unlocked

# 2. Authorize your Dev Hub
sf org login web --set-default-dev-hub --alias DevHub

# 3. Create a scratch org
sf org create scratch \
  --definition-file config/project-scratch-def.json \
  --alias Support360Dev \
  --duration-days 30 \
  --set-default

# 4. Deploy all source
sf project deploy start --target-org Support360Dev

# 5. Assign permission set to yourself
sf org assign permset --name Support360_Admin --target-org Support360Dev

# 6. Open the org
sf org open --target-org Support360Dev
```

Your org now has all SLA fields on Case, the trigger active, and the LWC available in App Builder.

---

## Project Structure

```
support360-unlocked/
├── .github/
│   └── workflows/
│       ├── pr-validation.yml       ← Scratch org validation on every PR
│       └── package-version.yml     ← Beta version creation on develop merge
│
├── config/
│   └── project-scratch-def.json    ← Scratch org feature configuration
│
├── force-app/main/default/
│   ├── classes/
│   │   ├── SLACalculator.cls           ← Core SLA calculation logic
│   │   ├── SLACalculatorTest.cls       ← 95%+ coverage test class
│   │   ├── EscalationService.cls       ← Escalation ladder + AuraEnabled methods
│   │   └── EscalationServiceTest.cls   ← Escalation unit tests
│   │
│   ├── triggers/
│   │   └── CaseTrigger.trigger     ← Single trigger, delegates to services
│   │
│   ├── objects/Case/fields/
│   │   ├── SLA_Breach_Date__c      ← DateTime: calculated SLA deadline
│   │   ├── SLA_Status__c           ← Picklist: Within SLA / At Risk / Breached
│   │   ├── Escalation_Level__c     ← Picklist: L1 through L4
│   │   └── SLA_Hours_By_Priority__c← Number: SLA hours for this case
│   │
│   ├── lwc/supportDashboard/
│   │   ├── supportDashboard.html   ← SLA dashboard UI
│   │   └── supportDashboard.js     ← Controller with wire, escalate handler
│   │
│   └── permissionsets/
│       ├── Support360_Admin.permissionset-meta.xml
│       └── Support360_User.permissionset-meta.xml
│
├── sfdx-project.json               ← Package config + Dev Hub connection
└── .forceignore                    ← Files excluded from org operations
```

---

## End-to-End: Create the Unlocked Package

### Step 1 — Register the Package with Dev Hub

```bash
sf package create \
  --name 'Support360' \
  --package-type Unlocked \
  --path force-app \
  --target-dev-hub DevHub
```

This writes the package `Id` (starts with `0Ho`) into `sfdx-project.json` under `packageAliases`. Commit this change.

### Step 2 — Create a Beta Package Version

```bash
sf package version create \
  --package 'Support360' \
  --installation-key-bypass \
  --code-coverage \
  --wait 20 \
  --target-dev-hub DevHub
```

Takes ~5–10 minutes. Note the `04t...` version ID in the output.

### Step 3 — Install the Beta Version in a Test Org

```bash
# Create a clean subscriber-simulation scratch org
sf org create scratch \
  --definition-file config/project-scratch-def.json \
  --alias Support360Test \
  --duration-days 1

# Install the package (no source push — pure install test)
sf package install \
  --package 04tXXXXXXXXXXXXXXX \
  --target-org Support360Test \
  --wait 10

# Run tests to confirm post-install behavior
sf apex run test \
  --target-org Support360Test \
  --class-names SLACalculatorTest,EscalationServiceTest \
  --result-format human
```

### Step 4 — Promote to Released

```bash
sf package version promote \
  --package 04tXXXXXXXXXXXXXXX \
  --no-prompt \
  --target-dev-hub DevHub
```

### Step 5 — Install in Real Org via URL

Share this URL with any Salesforce admin:
```
https://login.salesforce.com/packaging/installPackage.apexp?p0=04tXXXXXXXXXXXXXXX
```

---

## Running Tests Locally

```bash
# Deploy and run all tests in your scratch org
sf apex run test \
  --target-org Support360Dev \
  --code-coverage \
  --result-format human \
  --output-dir test-results \
  --wait 10
```

Expected results:
- `SLACalculatorTest` — 8 test methods, 100% pass
- `EscalationServiceTest` — 6 test methods, 100% pass
- Code coverage: SLACalculator ~98%, EscalationService ~95%

---

## CI/CD Setup (GitHub Actions)

Add this secret to your GitHub repository (Settings → Secrets → Actions):

| Secret | Value |
|---|---|
| `DEVHUB_SFDX_AUTH_URL` | Output of `sf org display --target-org DevHub --verbose --json \| jq -r '.result.sfdxAuthUrl'` |

Pipelines:
- **`pr-validation.yml`** — Runs on every PR. Creates scratch org, deploys, runs tests, deletes org.
- **`package-version.yml`** — Runs on push to `develop`. Creates Beta version + install test. Manual `promote` input for releases.

---

## Upgrade Instructions

See [UPGRADE_GUIDE.md](./UPGRADE_GUIDE.md) for 10 documented incremental upgrades with full instructions.

---

## Official Documentation

| Resource | URL |
|---|---|
| Salesforce DX Developer Guide | https://developer.salesforce.com/docs/atlas.en-us.sfdx_dev.meta/sfdx_dev/ |
| Unlocked Packages Guide | https://developer.salesforce.com/docs/atlas.en-us.sfdx_dev.meta/sfdx_dev/sfdx_dev_unlocked_pkg.htm |
| sf CLI Reference | https://developer.salesforce.com/docs/atlas.en-us.sfdx_cli_reference.meta/sfdx_cli_reference/ |
| Apex Developer Guide | https://developer.salesforce.com/docs/atlas.en-us.apexcode.meta/apexcode/ |
| LWC Developer Guide | https://developer.salesforce.com/docs/component-library/documentation/en/lwc |
