/**
 * CaseTrigger
 *
 * Single trigger per object pattern. All logic delegated to service classes.
 *
 * Hooks:
 *   BEFORE INSERT  → SLACalculator.calculateSLAFields
 *   BEFORE UPDATE  → SLACalculator.calculateSLAFields (on priority/status change)
 *   AFTER UPDATE   → EscalationService.autoEscalateOnBreach
 *
 * @group Support360
 */
trigger CaseTrigger on Case (before insert, before update, after update) {

    if (Trigger.isBefore && Trigger.isInsert) {
        SLACalculator.calculateSLAFields(Trigger.new);
    }

    if (Trigger.isBefore && Trigger.isUpdate) {
        SLACalculator.calculateSLAFields(Trigger.new);
        SLACalculator.refreshSLAStatus(Trigger.new);
    }

    if (Trigger.isAfter && Trigger.isUpdate) {
        EscalationService.autoEscalateOnBreach(Trigger.new, Trigger.oldMap);
    }
}
