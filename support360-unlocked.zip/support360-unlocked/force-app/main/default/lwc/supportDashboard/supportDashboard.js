import { LightningElement, track, wire } from 'lwc';
import { ShowToastEvent }                from 'lightning/platformShowToastEvent';
import { refreshApex }                   from '@salesforce/apex';
import getCasesWithSLA                   from '@salesforce/apex/SLACalculator.getCasesWithSLA';
import escalateCase                      from '@salesforce/apex/EscalationService.escalateCase';

const BASE_URL = window.location.origin;

const STATUS_OPTIONS = [
    { label: 'All Open Cases',  value: '' },
    { label: 'Breached',        value: 'Breached' },
    { label: 'At Risk',         value: 'At Risk' },
    { label: 'Within SLA',      value: 'Within SLA' },
];

const SLA_BADGE_CLASS = {
    'Breached':   'slds-badge_lightest slds-theme_error',
    'At Risk':    'slds-badge_lightest slds-theme_warning',
    'Within SLA': 'slds-badge_lightest slds-theme_success',
    'Excluded':   'slds-badge_lightest',
};

const PRIORITY_BADGE_CLASS = {
    'Critical': 'slds-badge_lightest slds-theme_error',
    'High':     'slds-badge_lightest slds-theme_warning',
    'Medium':   'slds-badge_lightest slds-theme_info',
    'Low':      'slds-badge_lightest',
};

const MAX_ESCALATION = 'L4 - Manager';

export default class SupportDashboard extends LightningElement {

    @track selectedStatus = '';
    @track cases          = [];
    @track isLoading      = false;

    _wiredResult;

    // ─── WIRE ─────────────────────────────────────────────────────────────────

    @wire(getCasesWithSLA)
    wiredCases(result) {
        this._wiredResult = result;
        if (result.data) {
            this.cases     = this._enrichCases(result.data);
            this.isLoading = false;
        }
        if (result.error) {
            this._showToast('Error loading cases', result.error.body?.message || 'Unknown error', 'error');
            this.isLoading = false;
        }
    }

    // ─── GETTERS ──────────────────────────────────────────────────────────────

    get statusOptions() { return STATUS_OPTIONS; }

    get filteredCases() {
        if (!this.selectedStatus) return this.cases;
        return this.cases.filter(c => c.SLA_Status__c === this.selectedStatus);
    }

    get hasCases() { return this.filteredCases.length > 0; }

    get summaryTiles() {
        const all      = this.cases;
        const breached = all.filter(c => c.SLA_Status__c === 'Breached').length;
        const atRisk   = all.filter(c => c.SLA_Status__c === 'At Risk').length;
        const within   = all.filter(c => c.SLA_Status__c === 'Within SLA').length;
        return [
            { label: 'Total Open',  count: all.length,  cssClass: 'tile tile--neutral' },
            { label: 'Breached',    count: breached,    cssClass: 'tile tile--error'   },
            { label: 'At Risk',     count: atRisk,      cssClass: 'tile tile--warning' },
            { label: 'Within SLA',  count: within,      cssClass: 'tile tile--success' },
        ];
    }

    // ─── HANDLERS ─────────────────────────────────────────────────────────────

    handleStatusChange(event) {
        this.selectedStatus = event.detail.value;
    }

    handleEscalate(event) {
        const caseId = event.currentTarget.dataset.caseId;
        this.isLoading = true;

        escalateCase({ caseId })
            .then(newLevel => {
                this._showToast('Case Escalated', `Escalation level updated to: ${newLevel}`, 'success');
                return refreshApex(this._wiredResult);
            })
            .catch(err => {
                this._showToast('Escalation Failed', err.body?.message || 'Unknown error', 'error');
            })
            .finally(() => {
                this.isLoading = false;
            });
    }

    // ─── PRIVATE ──────────────────────────────────────────────────────────────

    _enrichCases(rawCases) {
        return rawCases.map(c => ({
            ...c,
            caseUrl:         `${BASE_URL}/lightning/r/Case/${c.Id}/view`,
            slaClass:        SLA_BADGE_CLASS[c.SLA_Status__c]  || 'slds-badge_lightest',
            priorityClass:   PRIORITY_BADGE_CLASS[c.Priority]  || 'slds-badge_lightest',
            rowClass:        c.SLA_Status__c === 'Breached' ? 'slds-theme_shade' : '',
            isMaxEscalation: c.Escalation_Level__c === MAX_ESCALATION,
        }));
    }

    _showToast(title, message, variant) {
        this.dispatchEvent(new ShowToastEvent({ title, message, variant }));
    }
}
